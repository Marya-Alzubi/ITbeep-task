<?php echo e($body); ?>

<?php /**PATH C:\Users\orange\Documents\interviews_tasks\ITbeep\resources\views/emails/mail.blade.php ENDPATH**/ ?>